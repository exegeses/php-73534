<?php
    //require 'config/config.php';
    include 'layouts/header.php';
    include 'layouts/nav.php';
?>

    <main class="container py-4">
        <h1>Contenido de la sección</h1>

        <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque dignissimos ducimus eos error ipsa ipsum iste quia rem voluptas voluptatibus!
        </p>
    </main>

<?php
    include 'layouts/footer.php';
?>